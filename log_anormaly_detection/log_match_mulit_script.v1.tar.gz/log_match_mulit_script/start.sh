sh /mnt/data/AIOps/logAnormalyDetection/ai-match-mulit/log_match_multi.sh $*
