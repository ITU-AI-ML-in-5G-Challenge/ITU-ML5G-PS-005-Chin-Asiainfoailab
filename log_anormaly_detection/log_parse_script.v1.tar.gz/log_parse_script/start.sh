sh /mnt/data/AIOps/logAnormalyDetection/ai-log-parse/log_parse.sh $*
